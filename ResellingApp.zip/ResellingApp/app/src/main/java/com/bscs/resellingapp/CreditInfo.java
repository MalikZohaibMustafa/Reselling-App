package com.bscs.resellingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CreditInfo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_credit_info);
    }
}